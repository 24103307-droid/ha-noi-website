const express = require("express");
const cors = require("cors");
const cheerio = require("cheerio");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());


// Tao slug
function createSlug(text) {
    return text
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d")
        .replace(/[^a-z0-9\s-]/g, "")
        .trim()
        .replace(/\s+/g, "-");
}


// Xac dinh chuyen muc
function detectCategory(url) {

    // THE GIOI - CHUYEN MUC CON

    if (url.includes("/the-gioi/quan-su")) {
        return "quan-su";
    }

    if (url.includes("/the-gioi/phan-tich-binh-luan")) {
        return "phan-tich";
    }

    if (url.includes("/the-gioi/the-gioi-do-day")) {
        return "the-gioi-do-day";
    }

    if (url.includes("/the-gioi/kieu-bao")) {
        return "kieu-bao";
    }


    // THOI SU - CHUYEN MUC CON

    if (url.includes("/thoi-su/chinh-tri")) {
        return "chinh-tri";
    }

    if (url.includes("/thoi-su/giao-thong")) {
        return "giao-thong";
    }

    if (url.includes("/thoi-su/moi-truong")) {
        return "moi-truong";
    }

    if (url.includes("/thoi-su/nong-tren-mang")) {
        return "nong-tren-mang";
    }


    // CHUYEN MUC CHA

    if (url.includes("/the-gioi/")) {
        return "the-gioi";
    }

    if (url.includes("/thoi-su/")) {
        return "thoi-su";
    }


    return "latest";
}


// API crawler
app.post("/api/crawl", async function (req, res) {

    try {

        const articleUrl = req.body.url;


        // Kiem tra URL
        if (!articleUrl) {
            return res.status(400).json({
                error: "Thiếu URL bài viết."
            });
        }


        let parsedUrl;

        try {
            parsedUrl = new URL(articleUrl);
        } catch (error) {
            return res.status(400).json({
                error: "URL không hợp lệ."
            });
        }


        // Chi cho phep Dan tri
        if (
            parsedUrl.hostname !== "dantri.com.vn" &&
            parsedUrl.hostname !== "www.dantri.com.vn"
        ) {
            return res.status(400).json({
                error: "Crawler chỉ hỗ trợ dantri.com.vn."
            });
        }


        // Tai trang bai viet
        const response = await fetch(articleUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 NewsHub Student Project"
            }
        });


        if (!response.ok) {
            throw new Error("Không thể tải bài viết.");
        }


        // Lay HTML
        const html = await response.text();


        // Tao bien $ bang Cheerio
        const $ = cheerio.load(html);


        // Lay tieu de
        const title =
            $("h1").first().text().trim() ||
            $('meta[property="og:title"]').attr("content") ||
            "Không có tiêu đề";


        // Lay tom tat
        const excerpt =
            $('meta[name="description"]').attr("content") ||
            $('meta[property="og:description"]').attr("content") ||
            "";


        // Lay noi dung
        let content = "";

        $("article p").each(function () {

            const paragraph = $(this).text().trim();

            if (paragraph) {
                content += paragraph + "\n\n";
            }

        });


        // Neu article p khong lay duoc
        if (!content.trim()) {

            $('[class*="content"] p').each(function () {

                const paragraph = $(this).text().trim();

                if (paragraph) {
                    content += paragraph + "\n\n";
                }

            });

        }


        // Lay tac gia
        const author =
            $('meta[name="author"]').attr("content") ||
            $('[class*="author"]').first().text().trim() ||
            "Không rõ";


        // Lay thoi gian
        const publishedAt =
            $("time").first().attr("datetime") ||
            $("time").first().text().trim() ||
            $('meta[property="article:published_time"]').attr("content") ||
            "";


        // Lay anh
        // QUAN TRONG: dong nay nam sau khi da tao bien $
        const image =
            $('meta[property="og:image"]').attr("content") ||
            $("article img").first().attr("src") ||
            "";


        // Tao bai viet
        const article = {

            id: "post-" + Date.now(),

            title: title,

            slug: createSlug(title),

            excerpt: excerpt,

            content: content.trim(),

            author: author,

            category: detectCategory(articleUrl),

            publishedAt: publishedAt,

            image: image,

            source: parsedUrl.hostname,

            url: articleUrl

        };


        // Gui JSON ve frontend
        res.json(article);


    } catch (error) {

        console.error("Loi crawler:", error);

        res.status(500).json({
            error: "Không thể thu thập bài viết."
        });

    }

});
// ==========================================
// API CRAWLER CHUYEN MUC
// ==========================================

app.post("/api/crawl-category", async function (req, res) {

    try {

        const categoryUrl = req.body.url;


        // ==================================
        // KIEM TRA URL
        // ==================================

        if (!categoryUrl) {

            return res.status(400).json({
                error: "Thiếu URL chuyên mục."
            });

        }


        let parsedUrl;

        try {

            parsedUrl = new URL(categoryUrl);

        } catch (error) {

            return res.status(400).json({
                error: "URL chuyên mục không hợp lệ."
            });

        }


        // Chi cho phep Dan tri
        if (
            parsedUrl.hostname !== "dantri.com.vn" &&
            parsedUrl.hostname !== "www.dantri.com.vn"
        ) {

            return res.status(400).json({
                error: "Crawler chỉ hỗ trợ dantri.com.vn."
            });

        }


        // ==================================
        // TAI TRANG CHUYEN MUC
        // ==================================

        const response = await fetch(categoryUrl, {

            headers: {

                "User-Agent":
                    "Mozilla/5.0 NewsHub Student Project"

            }

        });


        if (!response.ok) {

            throw new Error(
                "Không thể tải trang chuyên mục."
            );

        }


        const html =
            await response.text();


        const $ =
            cheerio.load(html);


        // ==================================
        // TIM URL CAC BAI VIET
        // ==================================

        const articleUrls = [];


        $("a").each(function () {

            let href =
                $(this).attr("href");


            if (!href) {
                return;
            }


            // Chuyen link tuong doi thanh link day du
            try {

                const fullUrl =
                    new URL(
                        href,
                        "https://dantri.com.vn"
                    ).href;


                // Chi lay link cua Dan tri
                const articleParsedUrl =
                    new URL(fullUrl);


                if (
                    articleParsedUrl.hostname !== "dantri.com.vn" &&
                    articleParsedUrl.hostname !== "www.dantri.com.vn"
                ) {
                    return;
                }


                // Bai viet Dan tri thuong ket thuc bang .htm
                if (!fullUrl.includes(".htm")) {
                    return;
                }


                // Khong lay chinh URL chuyen muc
                if (fullUrl === categoryUrl) {
                    return;
                }


                // Khong lay trung URL
                if (!articleUrls.includes(fullUrl)) {

                    articleUrls.push(fullUrl);

                }

            } catch (error) {

                // Bo qua link loi

            }

        });


        // ==================================
        // CHI LAY TOI DA 10 BAI
        // ==================================

        const selectedUrls =
            articleUrls.slice(0, 10);


        if (selectedUrls.length === 0) {

            return res.status(404).json({

                error:
                    "Không tìm thấy bài viết trong chuyên mục."

            });

        }


        // ==================================
        // CRAWLER TUNG BAI
        // ==================================

        const articles = [];


        for (const articleUrl of selectedUrls) {

            try {

                const articleResponse =
                    await fetch(articleUrl, {

                        headers: {

                            "User-Agent":
                                "Mozilla/5.0 NewsHub Student Project"

                        }

                    });


                if (!articleResponse.ok) {

                    console.log(
                        "Bo qua bai:",
                        articleUrl
                    );

                    continue;

                }


                const articleHtml =
                    await articleResponse.text();


                const articlePage =
                    cheerio.load(articleHtml);


                // ==========================
                // TIEU DE
                // ==========================

                const title =
                    articlePage("h1")
                        .first()
                        .text()
                        .trim()
                    ||
                    articlePage(
                        'meta[property="og:title"]'
                    ).attr("content")
                    ||
                    "Không có tiêu đề";


                // ==========================
                // TOM TAT
                // ==========================

                const excerpt =
                    articlePage(
                        'meta[name="description"]'
                    ).attr("content")
                    ||
                    articlePage(
                        'meta[property="og:description"]'
                    ).attr("content")
                    ||
                    "";


                // ==========================
                // NOI DUNG
                // ==========================

                let content = "";


                articlePage("article p")
                    .each(function () {

                        const paragraph =
                            articlePage(this)
                                .text()
                                .trim();


                        if (paragraph) {

                            content +=
                                paragraph + "\n\n";

                        }

                    });


                // Thu selector khac neu article p rong
                if (!content.trim()) {

                    articlePage(
                        '[class*="content"] p'
                    ).each(function () {

                        const paragraph =
                            articlePage(this)
                                .text()
                                .trim();


                        if (paragraph) {

                            content +=
                                paragraph + "\n\n";

                        }

                    });

                }


                // ==========================
                // TAC GIA
                // ==========================

                const author =
                    articlePage(
                        'meta[name="author"]'
                    ).attr("content")
                    ||
                    articlePage(
                        '[class*="author"]'
                    )
                        .first()
                        .text()
                        .trim()
                    ||
                    "Không rõ";


                // ==========================
                // THOI GIAN
                // ==========================

                const publishedAt =
                    articlePage("time")
                        .first()
                        .attr("datetime")
                    ||
                    articlePage("time")
                        .first()
                        .text()
                        .trim()
                    ||
                    articlePage(
                        'meta[property="article:published_time"]'
                    ).attr("content")
                    ||
                    "";


                // ==========================
                // ANH
                // ==========================

                const image =
                    articlePage(
                        'meta[property="og:image"]'
                    ).attr("content")
                    ||
                    articlePage("article img")
                        .first()
                        .attr("src")
                    ||
                    "";


                // ==========================
                // TAO OBJECT BAI VIET
                // ==========================

                const article = {

                    id:
                        "post-" +
                        Date.now() +
                        "-" +
                        articles.length,

                    title:
                        title,

                    slug:
                        createSlug(title),

                    excerpt:
                        excerpt,

                    content:
                        content.trim(),

                    author:
                        author,

                    category:
                        detectCategory(articleUrl),

                    publishedAt:
                        publishedAt,

                    image:
                        image,

                    source:
                        "dantri.com.vn",

                    url:
                        articleUrl

                };


                articles.push(article);


            } catch (error) {

                console.error(
                    "Loi khi crawler bai:",
                    articleUrl,
                    error
                );

            }

        }


        // ==================================
        // TRA KET QUA
        // ==================================

        res.json({

            categoryUrl:
                categoryUrl,

            total:
                articles.length,

            articles:
                articles

        });


    } catch (error) {

        console.error(
            "Loi crawler chuyen muc:",
            error
        );


        res.status(500).json({

            error:
                "Không thể thu thập chuyên mục."

        });

    }

});

// Trang kiem tra server
app.get("/", function (req, res) {

    res.send("NewsHub Crawler Server đang hoạt động.");

});


// Khoi dong server
app.listen(PORT, function () {

    console.log(
        `Crawler server dang chay tai http://localhost:${PORT}`
    );

});