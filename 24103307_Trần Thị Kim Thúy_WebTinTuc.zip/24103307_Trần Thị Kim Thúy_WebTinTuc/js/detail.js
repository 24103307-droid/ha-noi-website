// ==========================================
// DETAIL.JS - TRANG CHI TIET BAI VIET
// ==========================================

document.addEventListener("DOMContentLoaded", async function () {

    await initializeData();

    renderNavbar();

    renderArticleDetail();

});


// ==========================================
// HIEN THI NAVBAR
// ==========================================

function renderNavbar() {

    const menuContainer =
        document.getElementById("category-menu");

    if (!menuContainer) {
        return;
    }

    const categories = getCategories();

    if (!categories || categories.length === 0) {

        menuContainer.innerHTML =
            "<p>Chưa có chuyên mục.</p>";

        return;
    }

    let html = `
        <a href="index.html" class="nav-link">
            Trang chủ
        </a>
    `;


    categories.forEach(function (category) {

        // Khong hien lai Trang chu
        if (category.id === "home") {
            return;
        }


        // ==================================
        // CHUYEN MUC CO MENU CON
        // ==================================

        if (
            category.children &&
            category.children.length > 0
        ) {

            html += `
                <div class="nav-dropdown">

                    <a
                        href="category.html?id=${category.id}"
                        class="nav-link"
                    >
                        ${category.title}
                        <span class="dropdown-arrow">▼</span>
                    </a>

                    <div class="dropdown-menu">
            `;


            category.children.forEach(function (child) {

                html += `
                    <a
                        href="category.html?id=${child.id}"
                        class="dropdown-link"
                    >
                        ${child.title}
                    </a>
                `;

            });


            html += `
                    </div>

                </div>
            `;

        }

        // ==================================
        // CHUYEN MUC KHONG CO MENU CON
        // ==================================

        else {

            html += `
                <a
                    href="category.html?id=${category.id}"
                    class="nav-link"
                >
                    ${category.title}
                </a>
            `;

        }

    });


    menuContainer.innerHTML = html;

}


// ==========================================
// LAY ID BAI VIET TU URL
// ==========================================

function getPostIdFromURL() {

    const params =
        new URLSearchParams(window.location.search);


    return params.get("id");

}


// ==========================================
// HIEN THI CHI TIET BAI VIET
// ==========================================

function renderArticleDetail() {

    const postId =
        getPostIdFromURL();


    if (!postId) {

        showError(
            "Không tìm thấy mã bài viết."
        );

        return;

    }


    const posts = getPosts();


    const post =
        posts.find(function (item) {

            return String(item.id) === String(postId);

        });


    if (!post) {

        showError(
            "Không tìm thấy bài viết."
        );

        return;

    }


    // Doi title cua tab trinh duyet
    document.title =
        post.title + " - NewsHub";


    const container =
        document.getElementById("article-detail");


    if (!container) {
        return;
    }


    const categoryName =
        getCategoryName(post.category);


    container.innerHTML = `

        <div class="article-category">

            <a href="category.html?id=${post.category}">
                ${categoryName}
            </a>

        </div>


        <h1 class="article-title">
            ${post.title}
        </h1>


        <div class="article-meta">

            <span>
                Tác giả:
                <strong>
                    ${getAuthorName(post.author)}
                </strong>
            </span>

            <span>
                ${formatDate(post.publishedAt)}
            </span>

        </div>


        ${
            post.excerpt
                ? `
                    <p class="article-excerpt">
                        ${post.excerpt}
                    </p>
                `
                : ""
        }


        ${
            post.image
                ? `
                    <img
                        src="${post.image}"
                        alt="${post.title}"
                        class="article-image"
                    >
                `
                : `
                    <div class="article-image-placeholder">
                        Chưa có ảnh
                    </div>
                `
        }


        <div class="article-content">

            ${formatContent(post.content)}

        </div>


        <div class="article-source">

            <p>
                <strong>Nguồn:</strong>
                ${post.source || "Không rõ"}
            </p>

            ${
                post.url
                    ? `
                        <p>
                            <a
                                href="${post.url}"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                Xem bài viết gốc
                            </a>
                        </p>
                    `
                    : ""
            }

        </div>

    `;

}


// ==========================================
// HIEN THI NOI DUNG BAI VIET
// ==========================================

function formatContent(content) {

    if (!content) {

        return `
            <p>
                Bài viết chưa có nội dung.
            </p>
        `;

    }


    // Tach noi dung theo dong
    const paragraphs =
        content
            .split(/\n+/)
            .map(function (paragraph) {

                return paragraph.trim();

            })
            .filter(function (paragraph) {

                return paragraph.length > 0;

            });


    if (paragraphs.length === 0) {

        return `
            <p>
                Bài viết chưa có nội dung.
            </p>
        `;

    }


    return paragraphs
        .map(function (paragraph) {

            return `<p>${paragraph}</p>`;

        })
        .join("");

}


// ==========================================
// LAY TEN TAC GIA
// ==========================================

function getAuthorName(author) {

    if (!author) {
        return "Không rõ";
    }


    // Ho tro du lieu author dang chuoi
    if (typeof author === "string") {
        return author;
    }


    // Ho tro du lieu author dang object
    if (
        typeof author === "object" &&
        author.name
    ) {
        return author.name;
    }


    return "Không rõ";

}


// ==========================================
// LAY TEN CHUYEN MUC
// ==========================================

function getCategoryName(categoryId) {

    const categories =
        getCategories();


    if (!categories) {
        return categoryId || "Tin tức";
    }


    for (const category of categories) {

        if (category.id === categoryId) {
            return category.title;
        }


        if (category.children) {

            const child =
                category.children.find(function (item) {

                    return item.id === categoryId;

                });


            if (child) {
                return child.title;
            }

        }

    }


    if (categoryId === "latest") {
        return "Mới nhất";
    }


    return categoryId || "Tin tức";

}


// ==========================================
// DINH DANG NGAY
// ==========================================

function formatDate(dateString) {

    if (!dateString) {
        return "Chưa có thời gian";
    }


    const date =
        new Date(dateString);


    if (Number.isNaN(date.getTime())) {
        return dateString;
    }


    return date.toLocaleString(
        "vi-VN",
        {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


// ==========================================
// THONG BAO LOI
// ==========================================

function showError(message) {

    const container =
        document.getElementById("article-detail");


    if (!container) {
        return;
    }


    container.innerHTML = `

        <div class="article-error">

            <h2>
                ${message}
            </h2>

            <p>
                <a href="index.html">
                    Quay lại trang chủ
                </a>
            </p>

        </div>

    `;

}