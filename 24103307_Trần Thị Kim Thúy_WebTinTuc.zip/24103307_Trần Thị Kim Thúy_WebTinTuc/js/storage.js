function saveCategories(categories) {
    localStorage.setItem("categories", JSON.stringify(categories));
}

function getCategories() {
    const categories = localStorage.getItem("categories");

    if (categories) {
        return JSON.parse(categories);
    }

    return null;
}

function savePosts(posts) {
    localStorage.setItem("posts", JSON.stringify(posts));
}

function getPosts() {
    const posts = localStorage.getItem("posts");

    if (posts) {
        return JSON.parse(posts);
    }

    return [];
}