// ==========================================
// CATEGORY.JS - TRANG CHUYEN MUC
// ==========================================

document.addEventListener("DOMContentLoaded", async function () {

    await initializeData();

    renderNavbar();

    renderCategoryPage();

});


// ==========================================
// HIEN THI NAVBAR
// ==========================================

function renderNavbar() {

    const menuContainer =
        document.getElementById("category-menu");

    if (!menuContainer) {
        return;
    }

    const categories = getCategories();

    if (!categories || categories.length === 0) {

        menuContainer.innerHTML =
            "<p>Chưa có chuyên mục.</p>";

        return;
    }

    let html = `
        <a href="index.html" class="nav-link">
            Trang chủ
        </a>
    `;


    categories.forEach(function (category) {

        // Khong hien lai Trang chu
        if (category.id === "home") {
            return;
        }


        // ==================================
        // CHUYEN MUC CO MENU CON
        // ==================================

        if (
            category.children &&
            category.children.length > 0
        ) {

            html += `
                <div class="nav-dropdown">

                    <a
                        href="category.html?id=${category.id}"
                        class="nav-link"
                    >
                        ${category.title}
                        <span class="dropdown-arrow">▼</span>
                    </a>

                    <div class="dropdown-menu">
            `;


            category.children.forEach(function (child) {

                html += `
                    <a
                        href="category.html?id=${child.id}"
                        class="dropdown-link"
                    >
                        ${child.title}
                    </a>
                `;

            });


            html += `
                    </div>

                </div>
            `;

        }

        // ==================================
        // CHUYEN MUC KHONG CO MENU CON
        // ==================================

        else {

            html += `
                <a
                    href="category.html?id=${category.id}"
                    class="nav-link"
                >
                    ${category.title}
                </a>
            `;

        }

    });


    menuContainer.innerHTML = html;

}


// ==========================================
// LAY ID CHUYEN MUC TU URL
// ==========================================

function getCategoryIdFromURL() {

    const params =
        new URLSearchParams(window.location.search);


    return params.get("id");

}


// ==========================================
// HIEN THI TRANG CHUYEN MUC
// ==========================================

function renderCategoryPage() {

    const categoryId =
        getCategoryIdFromURL();


    if (!categoryId) {

        showCategoryError(
            "Không tìm thấy chuyên mục."
        );

        return;

    }


    const posts = getPosts();

    const categoryTitle =
        document.getElementById("category-title");


    // ======================================
    // CHUYEN MUC MOI NHAT
    // ======================================

    if (categoryId === "latest") {

        if (categoryTitle) {
            categoryTitle.textContent =
                "Mới nhất";
        }


        const latestPosts = [...posts];


        latestPosts.sort(function (a, b) {

            return getPostTime(b.publishedAt)
                - getPostTime(a.publishedAt);

        });


        renderCategoryPosts(latestPosts);

        return;

    }


    // ======================================
    // TIM CHUYEN MUC
    // ======================================

    const categoryInfo =
        findCategory(categoryId);


    if (!categoryInfo) {

        showCategoryError(
            "Chuyên mục không tồn tại."
        );

        return;

    }


    if (categoryTitle) {

        categoryTitle.textContent =
            categoryInfo.title;

    }


    // ======================================
    // LOC BAI VIET
    // ======================================

    let filteredPosts = [];


    // Neu la chuyen muc cha
    if (
        categoryInfo.children &&
        categoryInfo.children.length > 0
    ) {

        const allowedCategories = [
            categoryInfo.id,
            ...categoryInfo.children.map(function (child) {
                return child.id;
            })
        ];


        filteredPosts =
            posts.filter(function (post) {

                return allowedCategories.includes(
                    post.category
                );

            });

    } else {

        // Neu la chuyen muc con
        filteredPosts =
            posts.filter(function (post) {

                return post.category === categoryId;

            });

    }


    // Sap xep moi nhat
    filteredPosts.sort(function (a, b) {

        return getPostTime(b.publishedAt)
            - getPostTime(a.publishedAt);

    });


    renderCategoryPosts(filteredPosts);

}


// ==========================================
// TIM CHUYEN MUC CHA HOAC CON
// ==========================================

function findCategory(categoryId) {

    const categories = getCategories();


    if (!categories) {
        return null;
    }


    for (const category of categories) {

        if (category.id === categoryId) {
            return category;
        }


        if (category.children) {

            const child =
                category.children.find(function (item) {

                    return item.id === categoryId;

                });


            if (child) {
                return child;
            }

        }

    }


    return null;

}


// ==========================================
// HIEN THI BAI TRONG CHUYEN MUC
// ==========================================

function renderCategoryPosts(posts) {

    if (!posts || posts.length === 0) {

        const featured =
            document.getElementById("featured-posts");

        const list =
            document.getElementById("post-list");


        if (featured) {

            featured.innerHTML =
                "<p>Chưa có bài viết trong chuyên mục này.</p>";

        }


        if (list) {
            list.innerHTML = "";
        }


        return;

    }


    const featuredPosts =
        posts.slice(0, 3);


    const remainingPosts =
        posts.slice(3);


    renderFeaturedPosts(featuredPosts);

    renderPostList(remainingPosts);

}


// ==========================================
// 3 BAI NOI BAT
// ==========================================

function renderFeaturedPosts(posts) {

    const container =
        document.getElementById("featured-posts");


    if (!container) {
        return;
    }


    if (!posts || posts.length === 0) {

        container.innerHTML = "";

        return;

    }


    const mainPost = posts[0];

    const sidePosts =
        posts.slice(1, 3);


    let html = `
        <div class="main-featured-post">

            <a href="detail.html?id=${mainPost.id}">

                ${
                    mainPost.image
                        ? `
                            <img
                                src="${mainPost.image}"
                                alt="${mainPost.title}"
                                class="main-post-image"
                            >
                        `
                        : `
                            <div class="image-placeholder">
                                Chưa có ảnh
                            </div>
                        `
                }

            </a>


            <div class="post-content">

                <span class="post-category">
                    ${getCategoryName(mainPost.category)}
                </span>


                <h2>
                    <a href="detail.html?id=${mainPost.id}">
                        ${mainPost.title}
                    </a>
                </h2>


                <p class="post-excerpt">
                    ${mainPost.excerpt || ""}
                </p>


                <p class="post-date">
                    ${formatDate(mainPost.publishedAt)}
                </p>

            </div>

        </div>


        <div class="side-featured-posts">
    `;


    sidePosts.forEach(function (post) {

        html += `
            <article class="side-post">

                <a href="detail.html?id=${post.id}">

                    ${
                        post.image
                            ? `
                                <img
                                    src="${post.image}"
                                    alt="${post.title}"
                                    class="side-post-image"
                                >
                            `
                            : `
                                <div class="small-image-placeholder">
                                    Chưa có ảnh
                                </div>
                            `
                    }

                </a>


                <div class="side-post-content">

                    <span class="post-category">
                        ${getCategoryName(post.category)}
                    </span>


                    <h3>
                        <a href="detail.html?id=${post.id}">
                            ${post.title}
                        </a>
                    </h3>


                    <p class="post-date">
                        ${formatDate(post.publishedAt)}
                    </p>

                </div>

            </article>
        `;

    });


    html += `
        </div>
    `;


    container.innerHTML = html;

}


// ==========================================
// DANH SACH CAC BAI CON LAI
// ==========================================

function renderPostList(posts) {

    const container =
        document.getElementById("post-list");


    if (!container) {
        return;
    }


    if (!posts || posts.length === 0) {

        container.innerHTML =
            "<p>Không còn bài viết khác.</p>";

        return;

    }


    let html = "";


    posts.forEach(function (post) {

        html += `
            <article class="post-item">

                <a href="detail.html?id=${post.id}">

                    ${
                        post.image
                            ? `
                                <img
                                    src="${post.image}"
                                    alt="${post.title}"
                                    class="list-post-image"
                                >
                            `
                            : `
                                <div class="list-image-placeholder">
                                    Chưa có ảnh
                                </div>
                            `
                    }

                </a>


                <div class="post-item-content">

                    <span class="post-category">
                        ${getCategoryName(post.category)}
                    </span>


                    <h3>
                        <a href="detail.html?id=${post.id}">
                            ${post.title}
                        </a>
                    </h3>


                    <p>
                        ${post.excerpt || ""}
                    </p>


                    <p class="post-date">
                        ${formatDate(post.publishedAt)}
                    </p>

                </div>

            </article>
        `;

    });


    container.innerHTML = html;

}


// ==========================================
// TEN CHUYEN MUC
// ==========================================

function getCategoryName(categoryId) {

    const category =
        findCategory(categoryId);


    if (category) {
        return category.title;
    }


    if (categoryId === "latest") {
        return "Mới nhất";
    }


    return categoryId || "Tin tức";

}


// ==========================================
// THOI GIAN DUNG DE SAP XEP
// ==========================================

function getPostTime(dateString) {

    if (!dateString) {
        return 0;
    }


    const time =
        new Date(dateString).getTime();


    if (Number.isNaN(time)) {
        return 0;
    }


    return time;

}


// ==========================================
// DINH DANG NGAY
// ==========================================

function formatDate(dateString) {

    if (!dateString) {
        return "Chưa có thời gian";
    }


    const date =
        new Date(dateString);


    if (Number.isNaN(date.getTime())) {
        return dateString;
    }


    return date.toLocaleString(
        "vi-VN",
        {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


// ==========================================
// THONG BAO LOI
// ==========================================

function showCategoryError(message) {

    const title =
        document.getElementById("category-title");

    const featured =
        document.getElementById("featured-posts");

    const list =
        document.getElementById("post-list");


    if (title) {
        title.textContent = "Chuyên mục";
    }


    if (featured) {
        featured.innerHTML = `<p>${message}</p>`;
    }


    if (list) {
        list.innerHTML = "";
    }

}