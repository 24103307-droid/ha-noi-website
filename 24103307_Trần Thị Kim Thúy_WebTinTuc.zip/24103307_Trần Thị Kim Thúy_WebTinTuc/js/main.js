// ==========================================
// MAIN.JS - TRANG CHU
// ==========================================

document.addEventListener("DOMContentLoaded", async function () {

    // Khoi tao du lieu tu file JSON neu LocalStorage chua co
    await initializeData();

    // Hien thi thanh chuyen muc
    renderNavbar();

    // Hien thi bai viet trang chu
    renderHomePosts();

});


// ==========================================
// HIEN THI NAVBAR
// ==========================================

function renderNavbar() {

    const menuContainer =
        document.getElementById("category-menu");

    if (!menuContainer) {
        return;
    }

    const categories = getCategories();

    if (!categories || categories.length === 0) {

        menuContainer.innerHTML =
            "<p>Chưa có chuyên mục.</p>";

        return;
    }

    let html = `
        <a href="index.html" class="nav-link">
            Trang chủ
        </a>
    `;


    categories.forEach(function (category) {

        // Khong hien lai Trang chu
        if (category.id === "home") {
            return;
        }


        // ==================================
        // CHUYEN MUC CO MENU CON
        // ==================================

        if (
            category.children &&
            category.children.length > 0
        ) {

            html += `
                <div class="nav-dropdown">

                    <a
                        href="category.html?id=${category.id}"
                        class="nav-link"
                    >
                        ${category.title}
                        <span class="dropdown-arrow">▼</span>
                    </a>

                    <div class="dropdown-menu">
            `;


            category.children.forEach(function (child) {

                html += `
                    <a
                        href="category.html?id=${child.id}"
                        class="dropdown-link"
                    >
                        ${child.title}
                    </a>
                `;

            });


            html += `
                    </div>

                </div>
            `;

        }

        // ==================================
        // CHUYEN MUC KHONG CO MENU CON
        // ==================================

        else {

            html += `
                <a
                    href="category.html?id=${category.id}"
                    class="nav-link"
                >
                    ${category.title}
                </a>
            `;

        }

    });


    menuContainer.innerHTML = html;

}


// ==========================================
// HIEN THI BAI VIET TRANG CHU
// ==========================================

function renderHomePosts() {

    const posts = getPosts();


    if (!posts || posts.length === 0) {

        const featured =
            document.getElementById("featured-posts");

        const list =
            document.getElementById("post-list");


        if (featured) {
            featured.innerHTML =
                "<p>Chưa có bài viết.</p>";
        }


        if (list) {
            list.innerHTML = "";
        }


        return;

    }


    // Tao ban sao de khong thay doi mang goc
    const sortedPosts = [...posts];


    // Sap xep bai moi nhat len truoc
    sortedPosts.sort(function (a, b) {

        return getPostTime(b.publishedAt)
            - getPostTime(a.publishedAt);

    });


    // 3 bai moi nhat
    const featuredPosts =
        sortedPosts.slice(0, 3);


    // Cac bai con lai
    const remainingPosts =
        sortedPosts.slice(3);


    renderFeaturedPosts(featuredPosts);

    renderPostList(remainingPosts);

}


// ==========================================
// HIEN THI 3 BAI NOI BAT
// 1 BAI LON + 2 BAI NHO
// ==========================================

function renderFeaturedPosts(posts) {

    const container =
        document.getElementById("featured-posts");


    if (!container) {
        return;
    }


    if (!posts || posts.length === 0) {

        container.innerHTML =
            "<p>Chưa có bài viết nổi bật.</p>";

        return;

    }


    const mainPost = posts[0];

    const sidePosts = posts.slice(1, 3);


    let html = `
        <div class="main-featured-post">

            <a href="detail.html?id=${mainPost.id}">

                ${
                    mainPost.image
                        ? `
                            <img
                                src="${mainPost.image}"
                                alt="${mainPost.title}"
                                class="main-post-image"
                            >
                        `
                        : `
                            <div class="image-placeholder">
                                Chưa có ảnh
                            </div>
                        `
                }

            </a>


            <div class="post-content">

                <span class="post-category">
                    ${getCategoryName(mainPost.category)}
                </span>


                <h2>
                    <a href="detail.html?id=${mainPost.id}">
                        ${mainPost.title}
                    </a>
                </h2>


                <p class="post-excerpt">
                    ${mainPost.excerpt || ""}
                </p>


                <p class="post-date">
                    ${formatDate(mainPost.publishedAt)}
                </p>

            </div>

        </div>


        <div class="side-featured-posts">
    `;


    sidePosts.forEach(function (post) {

        html += `
            <article class="side-post">

                <a href="detail.html?id=${post.id}">

                    ${
                        post.image
                            ? `
                                <img
                                    src="${post.image}"
                                    alt="${post.title}"
                                    class="side-post-image"
                                >
                            `
                            : `
                                <div class="small-image-placeholder">
                                    Chưa có ảnh
                                </div>
                            `
                    }

                </a>


                <div class="side-post-content">

                    <span class="post-category">
                        ${getCategoryName(post.category)}
                    </span>


                    <h3>
                        <a href="detail.html?id=${post.id}">
                            ${post.title}
                        </a>
                    </h3>


                    <p class="post-date">
                        ${formatDate(post.publishedAt)}
                    </p>

                </div>

            </article>
        `;

    });


    html += `
        </div>
    `;


    container.innerHTML = html;

}


// ==========================================
// HIEN THI CAC TIN CON LAI
// ==========================================

function renderPostList(posts) {

    const container =
        document.getElementById("post-list");


    if (!container) {
        return;
    }


    if (!posts || posts.length === 0) {

        container.innerHTML =
            "<p>Chưa có thêm bài viết.</p>";

        return;

    }


    let html = "";


    posts.forEach(function (post) {

        html += `
            <article class="post-item">

                <a href="detail.html?id=${post.id}">

                    ${
                        post.image
                            ? `
                                <img
                                    src="${post.image}"
                                    alt="${post.title}"
                                    class="list-post-image"
                                >
                            `
                            : `
                                <div class="list-image-placeholder">
                                    Chưa có ảnh
                                </div>
                            `
                    }

                </a>


                <div class="post-item-content">

                    <span class="post-category">
                        ${getCategoryName(post.category)}
                    </span>


                    <h3>
                        <a href="detail.html?id=${post.id}">
                            ${post.title}
                        </a>
                    </h3>


                    <p>
                        ${post.excerpt || ""}
                    </p>


                    <p class="post-date">
                        ${formatDate(post.publishedAt)}
                    </p>

                </div>

            </article>
        `;

    });


    container.innerHTML = html;

}


// ==========================================
// LAY TEN CHUYEN MUC
// ==========================================

function getCategoryName(categoryId) {

    const categories = getCategories();


    if (!categories) {
        return categoryId || "Tin tức";
    }


    for (const category of categories) {

        if (category.id === categoryId) {
            return category.title;
        }


        if (category.children) {

            const child =
                category.children.find(function (item) {

                    return item.id === categoryId;

                });


            if (child) {
                return child.title;
            }

        }

    }


    if (categoryId === "latest") {
        return "Mới nhất";
    }


    return categoryId || "Tin tức";

}


// ==========================================
// CHUYEN THOI GIAN THANH SO
// ==========================================

function getPostTime(dateString) {

    if (!dateString) {
        return 0;
    }


    const time =
        new Date(dateString).getTime();


    if (Number.isNaN(time)) {
        return 0;
    }


    return time;

}


// ==========================================
// DINH DANG NGAY
// ==========================================

function formatDate(dateString) {

    if (!dateString) {
        return "Chưa có thời gian";
    }


    const date =
        new Date(dateString);


    if (Number.isNaN(date.getTime())) {

        // Neu crawler tra ve chuoi ngay khong doc duoc
        // thi hien thi nguyen ban
        return dateString;

    }


    return date.toLocaleString(
        "vi-VN",
        {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}