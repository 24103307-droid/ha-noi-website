async function initializeData() {

    try {

        console.log("Bat dau khoi tao du lieu");

        if (!localStorage.getItem("categories")) {

            const categoryResponse = await fetch("data/categories.json");
            const categoryData = await categoryResponse.json();

            saveCategories(categoryData.menu);

            console.log("Da luu categories vao LocalStorage");
        }

        if (!localStorage.getItem("posts")) {

            const postResponse = await fetch("data/posts.json");
            const postData = await postResponse.json();

            savePosts(postData.posts);

            console.log("Da luu posts vao LocalStorage");
        }

        console.log("Khoi tao du lieu thanh cong");

    } catch (error) {

        console.error("Loi khi khoi tao du lieu:", error);

    }
}