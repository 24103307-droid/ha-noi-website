// Luu tam cac bai vua crawler tu chuyen muc
let crawledCategoryArticles = [];
document.addEventListener("DOMContentLoaded", async function () {

    await initializeData();

    renderNavbar();

    const crawlButton =
        document.getElementById("crawl-button");


    crawlButton.addEventListener("click", function () {

        crawlArticle();

    });

});


// ================================
// TAO NAVBAR
// ================================

function renderNavbar() {

    const menuContainer =
        document.getElementById("category-menu");

    if (!menuContainer) {
        return;
    }

    const categories = getCategories();

    if (!categories || categories.length === 0) {

        menuContainer.innerHTML =
            "<p>Chưa có chuyên mục.</p>";

        return;
    }

    let html = `
        <a href="index.html" class="nav-link">
            Trang chủ
        </a>
    `;


    categories.forEach(function (category) {

        // Khong hien lai Trang chu
        if (category.id === "home") {
            return;
        }


        // ==================================
        // CHUYEN MUC CO MENU CON
        // ==================================

        if (
            category.children &&
            category.children.length > 0
        ) {

            html += `
                <div class="nav-dropdown">

                    <a
                        href="category.html?id=${category.id}"
                        class="nav-link"
                    >
                        ${category.title}
                        <span class="dropdown-arrow">▼</span>
                    </a>

                    <div class="dropdown-menu">
            `;


            category.children.forEach(function (child) {

                html += `
                    <a
                        href="category.html?id=${child.id}"
                        class="dropdown-link"
                    >
                        ${child.title}
                    </a>
                `;

            });


            html += `
                    </div>

                </div>
            `;

        }

        // ==================================
        // CHUYEN MUC KHONG CO MENU CON
        // ==================================

        else {

            html += `
                <a
                    href="category.html?id=${category.id}"
                    class="nav-link"
                >
                    ${category.title}
                </a>
            `;

        }

    });


    menuContainer.innerHTML = html;

}


// ================================
// CRAWLER BAI VIET
// ================================

async function crawlArticle() {

    const urlInput =
        document.getElementById("article-url");

    const url =
        urlInput.value.trim();

    const result =
        document.getElementById("crawler-result");


    // Xoa ket qua cu
    result.innerHTML = "";


    // Kiem tra URL rong
    if (!url) {

        showMessage(
            "Vui lòng nhập URL bài viết.",
            "error"
        );

        return;

    }


    // Kiem tra URL hop le
    try {

        new URL(url);

    } catch (error) {

        showMessage(
            "URL không hợp lệ.",
            "error"
        );

        return;

    }


    // Thong bao dang xu ly
    showMessage(
        "Đang thu thập dữ liệu...",
        "loading"
    );


    try {

        // Gui URL sang crawler server
        const response = await fetch(
            "http://localhost:3000/api/crawl",
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    url: url

                })

            }
        );


        // Nhan JSON tu server
        const data =
            await response.json();


        // Neu server bao loi
        if (!response.ok) {

            throw new Error(
                data.error ||
                "Không thể thu thập bài viết."
            );

        }


        // Hien thi ket qua
        displayCrawlerResult(data);


        showMessage(
            "Thu thập dữ liệu thành công.",
            "success"
        );


    } catch (error) {

        console.error(
            "Loi crawler:",
            error
        );


        showMessage(
            error.message ||
            "Không thể kết nối với crawler server.",
            "error"
        );

    }

}

// ================================
// TAO SLUG
// ================================

function createSlug(text) {

    return text
        .toLowerCase()

        .normalize("NFD")

        .replace(
            /[\u0300-\u036f]/g,
            ""
        )

        .replace(/đ/g, "d")

        .replace(/[^a-z0-9\s-]/g, "")

        .trim()

        .replace(/\s+/g, "-");

}
// ================================
// NHAN DIEN CHUYEN MUC
// ================================

function detectCategory(url) {

    if (url.includes("/the-gioi/")) {

        return "the-gioi";

    }


    if (url.includes("/thoi-su/")) {

        return "thoi-su";

    }


    return "latest";

}
// ================================
// HIEN THI KET QUA
// ================================

function displayCrawlerResult(article) {

    const result =
        document.getElementById(
            "crawler-result"
        );


    result.innerHTML = `

        <h3>Kết quả thu thập</h3>


        <div class="crawler-preview">

            <p>
                <strong>Tiêu đề:</strong>
                ${article.title}
            </p>


            <p>
                <strong>Tác giả:</strong>
                ${article.author}
            </p>


            <p>
                <strong>Chuyên mục:</strong>
                ${article.category}
            </p>


            <p>
                <strong>Thời gian:</strong>
                ${article.publishedAt}
            </p>


            <p>
                <strong>Nguồn:</strong>
                ${article.source}
            </p>

        </div>


        <h3>JSON</h3>


        <pre class="json-result">${
            JSON.stringify(
                article,
                null,
                2
            )
        }</pre>


        <button
            type="button"
            id="save-article-button"
            class="save-article-button"
        >
            Lưu bài viết
        </button>

    `;


    document
        .getElementById(
            "save-article-button"
        )
        .addEventListener(
            "click",
            function () {

                saveCrawledArticle(article);

            }
        );

}
// ================================
// LUU BAI VIET
// ================================

function saveCrawledArticle(article) {

    const posts = getPosts();


    // Kiem tra URL da ton tai hay chua
    const existed =
        posts.some(function (post) {

            return post.url === article.url;

        });


    if (existed) {

        showMessage(
            "Bài viết này đã tồn tại.",
            "error"
        );

        return;

    }


    posts.push(article);


    savePosts(posts);


    showMessage(
        "Đã lưu bài viết vào LocalStorage.",
        "success"
    );

}
// ================================
// THONG BAO
// ================================

function showMessage(message, type) {

    const messageBox =
        document.getElementById(
            "crawler-message"
        );


    messageBox.className =
        "crawler-message " + type;


    messageBox.textContent =
        message;

}
// ==========================================
// CRAWLER CHUYEN MUC
// ==========================================


// Gan su kien cho nut crawler chuyen muc
document.addEventListener(
    "DOMContentLoaded",
    function () {

        const categoryButton =
            document.getElementById(
                "crawl-category-button"
            );


        if (categoryButton) {

            categoryButton.addEventListener(
                "click",
                crawlCategory
            );

        }

    }
);


// ==========================================
// GUI URL CHUYEN MUC SANG SERVER
// ==========================================

async function crawlCategory() {

    const urlInput =
        document.getElementById(
            "category-url"
        );


    const resultContainer =
        document.getElementById(
            "category-crawler-result"
        );


    const url =
        urlInput.value.trim();


    // Xoa ket qua cu
    resultContainer.innerHTML = "";


    // ======================================
    // KIEM TRA URL RONG
    // ======================================

    if (!url) {

        showCategoryMessage(
            "Vui lòng nhập URL chuyên mục.",
            "error"
        );

        return;

    }


    // ======================================
    // KIEM TRA URL HOP LE
    // ======================================

    try {

        new URL(url);

    } catch (error) {

        showCategoryMessage(
            "URL chuyên mục không hợp lệ.",
            "error"
        );

        return;

    }


    // ======================================
    // THONG BAO DANG XU LY
    // ======================================

    showCategoryMessage(
        "Đang thu thập các bài viết, vui lòng chờ...",
        "loading"
    );


    const button =
        document.getElementById(
            "crawl-category-button"
        );


    if (button) {

        button.disabled = true;

        button.textContent =
            "Đang thu thập...";

    }


    try {

        // ==================================
        // GUI REQUEST SANG SERVER
        // ==================================

        const response = await fetch(
            "http://localhost:3000/api/crawl-category",
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    url: url

                })

            }
        );


        // ==================================
        // NHAN JSON
        // ==================================

        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.error ||
                "Không thể thu thập chuyên mục."
            );

        }


        // ==================================
        // HIEN THI KET QUA
        // ==================================

        displayCategoryResult(data);


        showCategoryMessage(
            `Thu thập thành công ${data.total} bài viết.`,
            "success"
        );


    } catch (error) {

        console.error(
            "Loi crawler chuyen muc:",
            error
        );


        showCategoryMessage(
            error.message ||
            "Không thể kết nối crawler server.",
            "error"
        );


    } finally {

        // Bat lai nut
        if (button) {

            button.disabled = false;

            button.textContent =
                "Thu thập 10 bài";

        }

    }

}


// ==========================================
// HIEN THI DANH SACH BAI
// ==========================================

function displayCategoryResult(data) {
    // Luu tam danh sach bai vua crawler
    crawledCategoryArticles =
        data.articles || [];
    const container =
        document.getElementById(
            "category-crawler-result"
        );


    if (!container) {
        return;
    }


    if (
        !data.articles ||
        data.articles.length === 0
    ) {
    const saveArea =
        document.getElementById(
            "save-category-area"
        );

    if (saveArea) {
        saveArea.style.display = "none";
    }
        container.innerHTML = `
            <p>
                Không tìm thấy bài viết.
            </p>
        `;

        return;

    }
    const saveArea =
    document.getElementById(
        "save-category-area"
    );

if (saveArea) {
    saveArea.style.display = "block";
}


    let html = `

        <div class="category-result-header">

            <h3>
                Kết quả thu thập
            </h3>

            <p>
                Số bài:
                <strong>
                    ${data.total}
                </strong>
            </p>

        </div>


        <div class="category-article-list">

    `;


    data.articles.forEach(
        function (article, index) {

            html += `

                <article class="crawler-article-card">


                    <div class="crawler-article-number">

                        Bài ${index + 1}

                    </div>


                    ${
                        article.image
                            ? `
                                <img
                                    src="${article.image}"
                                    alt="${article.title}"
                                    class="crawler-article-image"
                                >
                            `
                            : `
                                <div class="crawler-no-image">
                                    Chưa có ảnh
                                </div>
                            `
                    }


                    <div class="crawler-article-info">


                        <h3>
                            ${article.title}
                        </h3>


                        <p>
                            <strong>
                                Chuyên mục:
                            </strong>

                            ${article.category}
                        </p>


                        <p>
                            <strong>
                                Tác giả:
                            </strong>

                            ${
                                typeof article.author === "object"
                                    ? article.author.name || "Không rõ"
                                    : article.author || "Không rõ"
                            }
                        </p>


                        <p>
                            <strong>
                                Thời gian:
                            </strong>

                            ${article.publishedAt || "Không rõ"}
                        </p>


                        <p>
                            <strong>
                                Tóm tắt:
                            </strong>

                            ${article.excerpt || "Không có"}
                        </p>


                        <p>
                            <a
                                href="${article.url}"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                Xem bài gốc
                            </a>
                        </p>


                    </div>

                </article>

            `;

        }
    );


    html += `
        </div>
    `;


    container.innerHTML = html;

}


// ==========================================
// THONG BAO CRAWLER CHUYEN MUC
// ==========================================

function showCategoryMessage(
    message,
    type
) {

    const messageBox =
        document.getElementById(
            "category-crawler-message"
        );


    if (!messageBox) {
        return;
    }


    messageBox.textContent =
        message;


    messageBox.className =
        "crawler-message " + type;

}
// ==========================================
// LUU TAT CA BAI CRAWLER CHUYEN MUC
// ==========================================

function saveAllCategoryArticles() {

    // Kiem tra co du lieu hay khong
    if (
        !crawledCategoryArticles ||
        crawledCategoryArticles.length === 0
    ) {

        showCategoryMessage(
            "Chưa có bài viết để lưu.",
            "error"
        );

        return;
    }


    // Lay danh sach bai dang co trong LocalStorage
    let posts = getPosts();

    if (!Array.isArray(posts)) {
        posts = [];
    }


    let addedCount = 0;
    let updatedCount = 0;


    crawledCategoryArticles.forEach(
        function (article) {

            // Tim bai trung dua vao URL
            const existingIndex =
                posts.findIndex(
                    function (post) {

                        return (
                            post.url === article.url
                        );

                    }
                );


            // ==================================
            // BAI DA TON TAI -> CAP NHAT
            // ==================================

            if (existingIndex !== -1) {

                posts[existingIndex] = {

                    ...posts[existingIndex],

                    ...article

                };

                updatedCount++;

            }


            // ==================================
            // BAI CHUA TON TAI -> THEM MOI
            // ==================================

            else {

                posts.push(article);

                addedCount++;

            }

        }
    );


    // Luu lai vao LocalStorage
    savePosts(posts);


    // Thong bao
    showCategoryMessage(
        `Đã lưu thành công. Thêm mới: ${addedCount} bài, cập nhật: ${updatedCount} bài.`,
        "success"
    );


    console.log(
        "Danh sach posts sau khi luu:",
        posts
    );

}
document.addEventListener(
    "DOMContentLoaded",
    function () {

        const saveAllButton =
            document.getElementById(
                "save-all-category-button"
            );


        if (saveAllButton) {

            saveAllButton.addEventListener(
                "click",
                saveAllCategoryArticles
            );

        }

    }
);